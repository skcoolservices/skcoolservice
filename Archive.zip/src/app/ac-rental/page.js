import AcOnRentTestimonialsSection from "@/Components/ACOnRent/ACOnRentTestimonials"
import AcOnRentWhyChooseSection from "@/Components/ACOnRent/AcOnRentWhyChoose"
import ACRentCtaSection from "@/Components/ACOnRent/ACRentCTA"
import AcOnRentHero from "@/Components/ACOnRent/ACRentHero"



const ACONRENT=()=>{
  return (
    <>
    
    <AcOnRentHero/>
    <AcOnRentWhyChooseSection/>
    <AcOnRentTestimonialsSection/>
    <ACRentCtaSection/>
    
    </>
  )
}
export default ACONRENT