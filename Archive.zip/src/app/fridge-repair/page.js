import FridgeRepairHero from "@/Components/FridgeRepair/FridgeReapirHero"
import FridgeRepairFinalFridgeRepairCTA from "@/Components/FridgeRepair/FridgeRepairCTA"
import FridgeRepairTestimonials from "@/Components/FridgeRepair/FridgeRepairTestimonial"
import FridgeRepairFeaturesWhyChoose from "@/Components/FridgeRepair/FridgeRepairWhyChoose"


const FridgeRepair=()=>{
    return (
        <>
        <FridgeRepairHero/>
        <FridgeRepairFeaturesWhyChoose/>
        <FridgeRepairTestimonials/>
        <FridgeRepairFinalFridgeRepairCTA/>
        
        </>
    )
}
export default FridgeRepair