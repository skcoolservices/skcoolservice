import ContactUsHero from "@/Components/ContactUs/ContactUsHero"
import ContactUsInfoDetails from "@/Components/ContactUs/ContactUsInfo"


const ContactUs=()=>{
    return (
        <>
        <ContactUsHero/>
        <ContactUsInfoDetails/>
        
        </>
    )
}
export default ContactUs